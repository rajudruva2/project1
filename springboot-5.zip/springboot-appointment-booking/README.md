# Appointment Booking Platform

    Provider scheduling with overlap prevention, rescheduling, cancellation, booking windows and searchable daily schedules.

    ## Technology
    - Java 21
    - Spring Boot 3.4.4
    - Maven
    - Spring Web, Bean Validation, Actuator
    - In-memory storage using Java collections (no database)

    ## Important database note
    This project has **no database dependency and no database configuration**. Data is held in application memory and is lost when the process/container restarts. This is intentional for a database-free DevOps lab.

    ## Run locally
    ```bash
    mvn clean verify
    mvn spring-boot:run
    ```
    Application port: `8083`

    Health check:
    ```bash
    curl http://localhost:8083/actuator/health
    ```

    ## Docker
    ```bash
    docker build -t springboot-appointment-booking:1.0 .
    docker run --rm -p 8083:8083 springboot-appointment-booking:1.0
    ```

    ## API endpoints
    ```text
    POST   /api/v1/appointments
GET    /api/v1/appointments/{id}
GET    /api/v1/appointments?providerId=...
PATCH  /api/v1/appointments/{id}/cancel
PUT    /api/v1/appointments/{id}/reschedule
    ```

    ## Example requests
    ```bash
    START=$(date -u -d '+2 hours' +%Y-%m-%dT%H:%M:%SZ)
END=$(date -u -d '+2 hours 30 minutes' +%Y-%m-%dT%H:%M:%SZ)
curl -X POST http://localhost:8083/api/v1/appointments -H 'Content-Type: application/json' -d "{\"providerId\":\"DOC-10\",\"customerId\":\"CUS-20\",\"start\":\"$START\",\"end\":\"$END\"}"
curl 'http://localhost:8083/api/v1/appointments?providerId=DOC-10'
    ```

    ## DevOps practice tasks
    1. Build the JAR with Maven and inspect the `target/` output.
    2. Build and run the Docker image; inspect logs and container health.
    3. Change the application port through an environment variable or JVM property.
    4. Add a GitHub Actions branch protection rule and inspect CI failures.
    5. Add structured logging and a correlation ID filter.
    6. Add API integration tests with MockMvc.
    7. Create Kubernetes Deployment and Service manifests; configure readiness and liveness probes.
    8. Add resource requests/limits and run a rolling update.
    9. Introduce a deliberate validation or business-rule bug and troubleshoot it.
    10. Document the impact of in-memory data loss during pod restart and propose a persistence strategy.

    ## Repository structure
    ```text
    src/main/java/   application, controller, service, records, exception handler
    src/main/resources/application.properties
    src/test/java/   service unit tests
    .github/workflows/ci.yml
    Dockerfile
    pom.xml
    ```
