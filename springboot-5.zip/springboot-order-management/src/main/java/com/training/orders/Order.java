package com.training.orders;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;
public record Order(Long id, String customerId, List<LineItem> items, BigDecimal total,
                    String status, Instant createdAt, long version) {
  public record LineItem(String sku, int quantity, BigDecimal unitPrice) {}
}
