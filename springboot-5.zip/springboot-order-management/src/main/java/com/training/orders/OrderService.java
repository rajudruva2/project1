package com.training.orders;
import org.springframework.stereotype.Service;
import java.math.BigDecimal;
import java.time.Instant;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
@Service
public class OrderService {
 private final Map<Long,Order> data=new ConcurrentHashMap<>();
 private final AtomicLong ids=new AtomicLong();
 public Order create(CreateOrderRequest r) {
  var lines=r.items().stream().map(i->new Order.LineItem(i.sku(),i.quantity(),i.unitPrice())).toList();
  var total=lines.stream().map(i->i.unitPrice().multiply(BigDecimal.valueOf(i.quantity())))
    .reduce(BigDecimal.ZERO,BigDecimal::add);
  var o=new Order(ids.incrementAndGet(),r.customerId(),lines,total,"CREATED",Instant.now(),0);
  data.put(o.id(),o); return o;
 }
 public Order get(long id){var o=data.get(id); if(o==null) throw new NoSuchElementException("Order "+id+" not found"); return o;}
 public List<Order> list(int page,int size){if(page<0||size<1||size>100)throw new IllegalArgumentException("page must be >=0 and size 1..100");
  return data.values().stream().sorted(Comparator.comparing(Order::createdAt).reversed()).skip((long)page*size).limit(size).toList();}
 public Order transition(long id,String target){var o=get(id); var allowed=Map.of(
  "CREATED",List.of("CONFIRMED","CANCELLED"),"CONFIRMED",List.of("SHIPPED","CANCELLED"),
  "SHIPPED",List.of("DELIVERED"),"DELIVERED",List.<String>of(),"CANCELLED",List.<String>of());
  if(!allowed.getOrDefault(o.status(),List.of()).contains(target))throw new IllegalStateException("Invalid transition "+o.status()+" -> "+target);
  var n=new Order(o.id(),o.customerId(),o.items(),o.total(),target,o.createdAt(),o.version()+1);data.put(id,n);return n;
 }
 public void delete(long id){get(id);data.remove(id);}
}
