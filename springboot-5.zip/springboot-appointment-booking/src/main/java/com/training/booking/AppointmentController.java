package com.training.booking;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/appointments")
public class AppointmentController {
 private final AppointmentService s;public AppointmentController(AppointmentService s){this.s=s;}
 @PostMapping @ResponseStatus(org.springframework.http.HttpStatus.CREATED) public Appointment book(@Valid @RequestBody AppointmentRequest r){return s.book(r);}
 @GetMapping("/{id}") public Appointment get(@PathVariable long id){return s.get(id);}
 @GetMapping public List<Appointment> provider(@RequestParam String providerId){return s.byProvider(providerId);}
 @PatchMapping("/{id}/cancel") public Appointment cancel(@PathVariable long id){return s.cancel(id);}
 @PutMapping("/{id}/reschedule") public Appointment reschedule(@PathVariable long id,@Valid @RequestBody AppointmentRequest r){return s.reschedule(id,r);}
}
