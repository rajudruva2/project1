package com.training.orders;
import jakarta.validation.Valid;
import jakarta.validation.constraints.*;
import java.math.BigDecimal;
import java.util.List;
public record CreateOrderRequest(@NotBlank String customerId,
  @NotEmpty List<@Valid Item> items) {
  public record Item(@NotBlank String sku, @Min(1) @Max(1000) int quantity,
                     @NotNull @DecimalMin("0.01") BigDecimal unitPrice) {}
}
