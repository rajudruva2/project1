package com.training.booking;
import jakarta.validation.constraints.*;
import java.time.Instant;
public record AppointmentRequest(@NotBlank String providerId,@NotBlank String customerId,@NotNull Instant start,@NotNull Instant end) {}
