package com.training.orders;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;
import java.util.List;
@RestController @RequestMapping("/api/v1/orders")
public class OrderController {
 private final OrderService service;
 public OrderController(OrderService service){this.service=service;}
 @PostMapping @ResponseStatus(org.springframework.http.HttpStatus.CREATED)
 public Order create(@Valid @RequestBody CreateOrderRequest r){return service.create(r);}
 @GetMapping("/{id}") public Order get(@PathVariable long id){return service.get(id);}
 @GetMapping public List<Order> list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="20") int size){return service.list(page,size);}
 @PatchMapping("/{id}/status") public Order status(@PathVariable long id,@RequestParam String target){return service.transition(id,target);}
 @DeleteMapping("/{id}") @ResponseStatus(org.springframework.http.HttpStatus.NO_CONTENT) public void delete(@PathVariable long id){service.delete(id);}
}
