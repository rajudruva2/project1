package com.training.orders;
import org.junit.jupiter.api.Test;
import java.math.BigDecimal;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
class OrderServiceTest {
 @Test void calculatesTotalAndTransitions(){
  var s=new OrderService(); var o=s.create(new CreateOrderRequest("C-1",List.of(new CreateOrderRequest.Item("SKU-1",2,new BigDecimal("12.50")))));
  assertEquals(new BigDecimal("25.00"),o.total()); assertEquals("CREATED",o.status());
  assertEquals("CONFIRMED",s.transition(o.id(),"CONFIRMED").status());
 }
}
