package com.training.booking;
import org.junit.jupiter.api.Test;
import java.time.Instant;
import static org.junit.jupiter.api.Assertions.*;
class AppointmentServiceTest {
 @Test void preventsOverlappingBookings(){var s=new AppointmentService();var start=Instant.now().plusSeconds(3600);
  s.book(new AppointmentRequest("P1","C1",start,start.plusSeconds(1800)));
  assertThrows(IllegalStateException.class,()->s.book(new AppointmentRequest("P1","C2",start.plusSeconds(600),start.plusSeconds(2400))));}
}
