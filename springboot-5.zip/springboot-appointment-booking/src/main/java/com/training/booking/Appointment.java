package com.training.booking;
import java.time.Instant;
public record Appointment(Long id,String providerId,String customerId,Instant start,Instant end,String status) {}
