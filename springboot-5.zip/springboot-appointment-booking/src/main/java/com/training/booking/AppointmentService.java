package com.training.booking;
import org.springframework.stereotype.Service;
import java.time.*;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;
@Service
public class AppointmentService {
 private final Map<Long,Appointment> data=new ConcurrentHashMap<>();private final AtomicLong ids=new AtomicLong();
 public synchronized Appointment book(AppointmentRequest r){validate(r);if(r.start().isBefore(Instant.now()))throw new IllegalArgumentException("Appointment must be in the future");
  if(overlap(r.providerId(),r.start(),r.end(),null))throw new IllegalStateException("Provider already has an overlapping appointment");
  var a=new Appointment(ids.incrementAndGet(),r.providerId(),r.customerId(),r.start(),r.end(),"BOOKED");data.put(a.id(),a);return a;}
 private void validate(AppointmentRequest r){if(!r.end().isAfter(r.start()))throw new IllegalArgumentException("end must be after start");
  if(Duration.between(r.start(),r.end()).toMinutes()>240)throw new IllegalArgumentException("Appointment cannot exceed 4 hours");}
 private boolean overlap(String p,Instant s,Instant e,Long except){return data.values().stream().anyMatch(a->a.providerId().equals(p)&&a.status().equals("BOOKED")&&!Objects.equals(a.id(),except)&&s.isBefore(a.end())&&e.isAfter(a.start()));}
 public Appointment get(long id){var a=data.get(id);if(a==null)throw new NoSuchElementException("Appointment not found");return a;}
 public List<Appointment> byProvider(String p){return data.values().stream().filter(a->a.providerId().equals(p)).sorted(Comparator.comparing(Appointment::start)).toList();}
 public synchronized Appointment cancel(long id){var a=get(id);if(!a.status().equals("BOOKED"))throw new IllegalStateException("Only booked appointments can be cancelled");
  var n=new Appointment(a.id(),a.providerId(),a.customerId(),a.start(),a.end(),"CANCELLED");data.put(id,n);return n;}
 public synchronized Appointment reschedule(long id,AppointmentRequest r){var a=get(id);if(!a.status().equals("BOOKED"))throw new IllegalStateException("Only booked appointments can be rescheduled");validate(r);
  if(!a.providerId().equals(r.providerId())||overlap(r.providerId(),r.start(),r.end(),id))throw new IllegalStateException("Provider unavailable for requested time");
  var n=new Appointment(id,r.providerId(),r.customerId(),r.start(),r.end(),"BOOKED");data.put(id,n);return n;}
}
